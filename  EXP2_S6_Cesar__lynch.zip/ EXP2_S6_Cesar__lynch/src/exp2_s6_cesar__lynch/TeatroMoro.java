/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exp2_s6_cesar__lynch;

/**
 *
 * @author sd
 */
public class TeatroMoro {

    // Variables
    private int Vendidas = 0;
    private int total = 0;
    private int[][] entradasVendidas; 

    //  estáticas
    private static int capacidad = 50;
    private static int Disponibles = 50;
    private static int precioUni = 2500;

    //  locales
    private String tipoEntrada;
    private int descuentoTemporal;
    private int numeroEntrada;
    private int ubicacion;

    // Construc.
    public TeatroMoro() {
        entradasVendidas = new int[capacidad][3]; 
    }

    
    public void venderEntrada(String tipoEntrada, int descuentoTemporal, int numeroEntrada, int ubicacion) {
        if (Disponibles > 0) {
            int precioFinal = calcularPrecioFinal(descuentoTemporal);
            
           
            total += precioFinal;
            Vendidas++;
            Disponibles--;

            
            entradasVendidas[numeroEntrada - 1][0] = numeroEntrada;
            entradasVendidas[numeroEntrada - 1][1] = ubicacion;
            entradasVendidas[numeroEntrada - 1][2] = precioFinal;

            System.out.println("Entrada vendida exitosamente. Precio: " + precioFinal);
        } else {
            System.out.println("No hay entradas disponibles.");
        }
    }

    
    private int calcularPrecioFinal(int descuentoTemporal) {
        return precioUni - descuentoTemporal;
    }

    
    public void mostrarEstadisticas() {
        System.out.println("Total de ingresos: " + total);
        System.out.println("Número de entradas vendidas: " + Vendidas);
        System.out.println("Número de entradas disponibles: " + Disponibles);
    }

    public static void main(String[] args) {
        TeatroMoro teatro = new TeatroMoro();
        
        
        teatro.venderEntrada("Normal", 0, 1, 101);
        teatro.venderEntrada("Estudiante", 10, 2, 102);
        
    
        teatro.mostrarEstadisticas();
    }
}